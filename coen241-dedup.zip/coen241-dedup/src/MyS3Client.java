import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;

public class MyS3Client {

	static final String BUCKET_NAME = "dedupbucket-d0";
	static AmazonS3 client;

	public MyS3Client() {
		AWSCredentials credentials = null;
		try {
			credentials = new ProfileCredentialsProvider("default").getCredentials();
		} catch (Exception e) {
			throw new AmazonClientException("Cannot load the credentials from the credential profiles file. "
					+ "Please make sure that your credentials file is at the correct "
					+ "location (/Users/<username>/.aws/credentials), and is in valid format.", e);
		}
		client = new AmazonS3Client(credentials);
	}

	// Uploads a file to all buckets in our S3
	public void uploadFile(File file) {
		try {
			System.out.println("Uploading: " + file.getName());
			
			client.putObject(new PutObjectRequest(BUCKET_NAME, file.getName(), file));
			
		} catch (AmazonServiceException ase) {
			System.out.println("Caught an AmazonServiceException, which " + "means your request made it "
					+ "to Amazon S3, but was rejected with an error response" + " for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out.println("Caught an AmazonClientException, which " + "means the client encountered "
					+ "an internal error while trying to " + "communicate with S3, "
					+ "such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		}
	}

	// Downloads file from S3
	public void downloadFile(String fileName, ArrayList<String> segments) {
		int attempt = 0;
		FileOutputStream fos = null;
		BufferedOutputStream bos = null;
		try {
			fos = new FileOutputStream(fileName);
			bos = new BufferedOutputStream(fos);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		
		S3Object s3Object = new S3Object();
		boolean done = false;
		while (!done) {
			String s3Bucket = BUCKET_NAME;
			try {
				for (int i = 0; i < segments.size(); i++) {
					System.out.println("Downloading: " + segments.get(i));
					s3Object = client.getObject(new GetObjectRequest(s3Bucket, segments.get(i)));
					constructFile(bos, fileName, s3Object); // Recompiles the file
				}
				fos.close();
				done = true;
			} catch (AmazonServiceException ase) {
				System.out.println("Caught an AmazonServiceException, which " + "means your request made it "
						+ "to Amazon S3, but was rejected with an error response" + " for some reason.");
				System.out.println("Error Message:    " + ase.getMessage());
				System.out.println("HTTP Status Code: " + ase.getStatusCode());
				System.out.println("AWS Error Code:   " + ase.getErrorCode());
				System.out.println("Error Type:       " + ase.getErrorType());
				System.out.println("Request ID:       " + ase.getRequestId());
				if (attempt == 2) {
					// We failed!
					System.err.println("Failed to get segment in 3 attempts");
					System.exit(1);
				} else
					attempt++;
			} catch (AmazonClientException ace) {
				System.out.println("Caught an AmazonClientException, which " + "means the client encountered "
						+ "an internal error while trying to " + "communicate with S3, "
						+ "such as not being able to access the network.");
				System.out.println("Error Message: " + ace.getMessage());
				if (attempt == 2) {
					// We failed!
					System.err.println("Failed to get segment in 3 attempts");
					System.exit(1);
				} else
					attempt++;
			} catch (IOException e) {
				System.out.println(e);
			}
		}
	}

	// Takes the S3 segment objects, checks them for length, and creates the
	// file
	private static void constructFile(BufferedOutputStream bos, String fileName, S3Object s3object) throws IOException {
			InputStream is = s3object.getObjectContent();
			
			ByteArrayOutputStream baos = new ByteArrayOutputStream(8192);
			
			byte[] b = new byte[1];
			int bytesRead = is.read(b);
			
			do {
				baos.write(b);
				bytesRead = is.read(b);
			} while(bytesRead != -1);
			
			bos.write(baos.toByteArray());
			bos.flush();
			is.close();
	}

	public void deleteSegment(String segment) {
		try {
			System.out.println("Deleting: " + segment);
			
			client.deleteObject(new DeleteObjectRequest(BUCKET_NAME, segment));
			
		} catch (AmazonServiceException ase) {
			System.out.println("Caught an AmazonServiceException, which " + "means your request made it "
					+ "to Amazon S3, but was rejected with an error response" + " for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out.println("Caught an AmazonClientException, which " + "means the client encountered "
					+ "an internal error while trying to " + "communicate with S3, "
					+ "such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		}
	}

}
