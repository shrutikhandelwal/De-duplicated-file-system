import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class DedupClient {
	/**
	 * Segmentation and finger-printing of files should return a list of segment
	 * names (e.g. finger prints). A new file should be created that contains a
	 * list of segments to reconstruct the file.
	 */

	/**
	 * The metadata file contains information on the number of segments a file
	 * is split into and the segments that make up the file.
	 */
	private static HashSet<String> prepareSegments(File metadata) {
		HashSet<String> segments = new HashSet<>();
		try (BufferedReader br = new BufferedReader(new FileReader(metadata))) {
			String line;
			while ((line = br.readLine()) != null) {
				List<String> arr = Arrays.asList(line.split(","));
				segments.add(arr.get(0));
			}
		} catch (IOException e) {
			System.out.println(e);
		}
		return segments;
	}

	/**
	 * Input is a set of segments/finger prints. It communicates with EC2 to
	 * determine which need to be uploaded. Returns a set of segments that are
	 * unique and thus need to be uploaded.
	 */
	public static HashSet<String> getFilesToUpload(HashSet<String> segments, String address, int port) {
		HashSet<String> toUpload = new HashSet<String>();
		try (Socket socket = new Socket(address, port);
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
				BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
			out.println("duplicate check");
			String input;
			for (String segment : segments) {
				out.println(segment);
				if ((input = in.readLine()) != null && input.equals("upload")) {
					toUpload.add(segment);
				}
			}
		} catch (IOException e) {
			System.out.println(e);
		}
		return toUpload;
	}

	// This sends the file to EC2 server
	public static void sendFile(File file, String address, int port) {
		try (Socket socket = new Socket(address, port);
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
				FileInputStream fis = new FileInputStream(file);
				BufferedInputStream bis = new BufferedInputStream(fis);
				BufferedOutputStream toServer = new BufferedOutputStream(socket.getOutputStream());) {
			out.println("upload " + file.getName() + " " + file.length()); // upload
																			// filename
			byte[] fileByteArray = new byte[(int) file.length()];
			bis.read(fileByteArray, 0, fileByteArray.length);
			toServer.write(fileByteArray, 0, fileByteArray.length);
			pause(1); // Note: need to sleep for byte array to populate
			toServer.flush();
		} catch (IOException e) {
			System.out.println(e);
		}
	}

	public static ArrayList<String> getFileSegments(String fileName, String address, int port) {
		try (Socket socket = new Socket(address, port);
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
				BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
			out.println("get " + fileName); // Tell server which file we want
			String input;
			input = in.readLine();
			if (input.equals("File does not exist!")) {
				System.err.println(fileName + " does not exist!");
				System.exit(1);
			} else {
				// Build our array of segments
				ArrayList<String> arr = new ArrayList<String>();
				String line;
				while ((line = in.readLine()) != null) {
					List<String> list = Arrays.asList(line.split(","));
					arr.add(list.get(0));
				}
				
				return arr;
			}
		} catch (IOException e) {
			System.out.println(e);
		}
		return null;
	}

	public static void deleteFile(String fileName, String address, int port) {
		try (Socket socket = new Socket(address, port);
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
				BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
			out.println("delete " + fileName);
			String input = in.readLine();
			if (input.equals("File does not exist!")) {
				System.out.println(fileName + " does not exist!");
			}
		} catch (IOException e) {
			System.out.println(e);
		}
	}

	private static void pause(int ms) {
		try {
			TimeUnit.MILLISECONDS.sleep(ms);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}

	public static void main(String[] args) {
		if (args.length != 4) {
			System.err.println("Usage: java DedupClient [put | get] [file] [address] [port]");
			System.exit(1);
		}
		// Collection information
		String command = args[0]; // put, get, or delete
		String myFile = args[1]; // file path or file name
		String address = args[2]; // server's address
		int port = Integer.parseInt(args[3]); // server's port
		ContentBasedChunking cbc = new ContentBasedChunking();
		
		// Metadata of file to be sent to server
		File metadata = new File(myFile + ".data");

		if (command.equalsIgnoreCase("put")) {
			/* 
			 * Step 1: Segment and finger print the files (output is metadata file)
			 */
			
			// File we want to upload 
			File file = new File(myFile); 
			
			// Directory containing our file, its metadata, and its segments
			String fileDir = file.getParent(); 
			System.out.println("fileDir: " + fileDir);
			
			try {
				cbc.digest(myFile);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			// Step 2: Determine segments of our file
			HashSet<String> segments = prepareSegments(metadata);
			
			// Step 3:Determine segments that need to be uploaded
			HashSet<String> toUpload = getFilesToUpload(segments, address, port);
			
			// Step 4: Send metadata file to the server
			sendFile(metadata, address, port);
			
			// Step 5: Initialize S3 client
			MyS3Client client = new MyS3Client();
			
			// Step 6: Send segments to buckets
			for (String upload : toUpload) {
				File seg = new File(fileDir + "/" + upload);
				client.uploadFile(seg);
				seg.delete();
			}
			
			metadata.delete();
		}
		if (command.equalsIgnoreCase("get")) {
			// Step 1: Get the segments needed to reconstruct our file
			ArrayList<String> fileSegments = getFileSegments(metadata.getName(), address, port);
			// Step 2: Initialize S3 client
			MyS3Client client = new MyS3Client();
			// Step 3: Download objects from S3
			client.downloadFile(myFile, fileSegments);
		}
		if (command.equalsIgnoreCase("delete")) {
			deleteFile(metadata.getName(), address, port);
		}
	}

}
